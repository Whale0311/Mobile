package com.example.calculator

import android.os.Bundle
import android.widget.Button
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import com.example.calculator.R

class MainActivity : AppCompatActivity() {
    private lateinit var tvResult: TextView
    private var currentNumber = ""
    private var operator: Char? = null
    private var firstNumber: Int? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        tvResult = findViewById(R.id.tvResult)

        val buttons = listOf(
            R.id.button0, R.id.button1, R.id.button2, R.id.button3, R.id.button4,
            R.id.button5, R.id.button6, R.id.button7, R.id.button8, R.id.button9
        )

        buttons.forEach { id ->
            findViewById<Button>(id).setOnClickListener { onNumberClick((it as Button).text.toString()) }
        }

        findViewById<Button>(R.id.buttonPlus).setOnClickListener { onOperatorClick('+') }
        findViewById<Button>(R.id.buttonMinus).setOnClickListener { onOperatorClick('-') }
        findViewById<Button>(R.id.buttonMultiply).setOnClickListener { onOperatorClick('x') }
        findViewById<Button>(R.id.buttonDivide).setOnClickListener { onOperatorClick('/') }

        findViewById<Button>(R.id.buttonEqual).setOnClickListener { onEqualClick() }
        findViewById<Button>(R.id.  buttonClear).setOnClickListener { onClearClick() }
    }

    private fun onNumberClick(number: String) {
        currentNumber += number
        tvResult.text = currentNumber
    }

    private fun onOperatorClick(op: Char) {
        if (currentNumber.isNotEmpty()) {
            firstNumber = currentNumber.toInt()
            operator = op
            currentNumber = ""
        }
    }

    private fun onEqualClick() {
        if (firstNumber != null && currentNumber.isNotEmpty() && operator != null) {
            val secondNumber = currentNumber.toInt()
            val result = when (operator) {
                '+' -> firstNumber!! + secondNumber
                '-' -> firstNumber!! - secondNumber
                'x' -> firstNumber!! * secondNumber
                '/' -> if (secondNumber != 0) firstNumber!! / secondNumber else 0
                else -> 0
            }
            tvResult.text = result.toString()
            currentNumber = result.toString()
            firstNumber = null
            operator = null
        }
    }

    private fun onClearClick() {
        currentNumber = ""
        firstNumber = null
        operator = null
        tvResult.text = "0"
    }
}